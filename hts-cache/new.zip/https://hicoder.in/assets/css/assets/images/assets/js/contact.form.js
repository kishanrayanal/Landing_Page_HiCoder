<!DOCTYPE html>


    <head>        
        <meta name="google-site-verification" content="X0kRhdQLVaTaDeaz1MgxeOdZfJ6Kw-LCsC-J7Rj8r7U" />
        <!-- responsive tag -->
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- favicon -->
        <link rel="apple-touch-icon" href="apple-touch-icon.png">
        <link rel="shortcut icon" type="image/x-icon" href="assets/images/fav.png">
        <!-- Bootstrap v4.4.1 css -->
        <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
        <!-- font-awesome css -->
        <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
        <!-- animate css -->
        <link rel="stylesheet" type="text/css" href="assets/css/animate.css">
        <!-- owl.carousel css -->
        <link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.css">
        <!-- slick css -->
        <link rel="stylesheet" type="text/css" href="assets/css/slick.css">
        <!-- off canvas css -->
        <link rel="stylesheet" type="text/css" href="assets/css/off-canvas.css">
        <!-- linea-font css -->
        <link rel="stylesheet" type="text/css" href="assets/fonts/linea-fonts.css">
        <!-- flaticon css  -->
        <link rel="stylesheet" type="text/css" href="assets/fonts/flaticon.css">
        <!-- magnific popup css -->
        <link rel="stylesheet" type="text/css" href="assets/css/magnific-popup.css">
        <!-- Main Menu css -->
        <link rel="stylesheet" href="assets/css/rsmenu-main.css">
        <!-- nivo slider CSS -->
        <link rel="stylesheet" type="text/css" href="assets/inc/custom-slider/css/nivo-slider.css">
        <link rel="stylesheet" type="text/css" href="assets/inc/custom-slider/css/preview.css">
        <!-- rsmenu transitions css -->
        <link rel="stylesheet" href="assets/css/rsmenu-transitions.css">
        <!-- spacing css -->
        <link rel="stylesheet" type="text/css" href="assets/css/rs-spacing.css">
        <!-- style css -->
        <link rel="stylesheet" type="text/css" href="assets/css/style.css"> <!-- This stylesheet dynamically changed from style.less -->
        <!-- responsive css -->
        <link rel="stylesheet" type="text/css" href="assets/css/responsive.css">

        <link rel="stylesheet" type="text/css" href="assets/css/custom.css"> <!-- This stylesheet dynamically changed from style.less -->
        
        

        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->



    
<!-- Meta Starts -->
<!-- Meta Ends -->
</head>
<body class="home-eight">

    <!-- Preloader area start here -->
    <div id="loader" class="loader">
        <div class="spinner"></div>
    </div>
    <!--End preloader here -->

    <!--Full width header Start-->
    <div class="full-width-header header-style4">
        <!-- Toolbar Start -->
        <div class="toolbar-area hidden-md">
            <div class="container">
                <div class="row">
                    <div class="col-md-5">
                        <div class="toolbar-contact">
                            <ul>
                                <li><i class="flaticon-email"></i><a href="/cdn-cgi/l/email-protection#e48580898d97978d8b8aa48c8d878b808196ca8d8a"><span class="__cf_email__" data-cfemail="3b5a5f565248485254557b535258545f5e49155255">[email&#160;protected]</span></a></li>
                                <li><i class="flaticon-call"></i><a href="tel:+919206980980">(+91) 9206 980 980</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-7">
                        <div class="toolbar-sl-share">
                            <ul>
                                <li class="opening"> <i class="flaticon-clock"></i> Mon - Fri: 10:00am - 06.00pm</li>
                                <li><a href="https://www.facebook.com/hicoderofficial" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="https://www.instagram.com/hicoderofficial/" target="_blank"><i class="fa fa-instagram"></i></a></li>
                                <li><a href="https://twitter.com/hicoderofficial" target="_blank"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="https://www.linkedin.com/company/69513594/" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Toolbar End -->
        
        <!--Header Start-->
        <header id="rs-header" class="rs-header">
            <!-- Menu Start -->
            <div class="menu-area menu-sticky">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="logo-area">
                                <a href="/"><img src="assets/images/logo-dark.png" alt="logo"></a>
                            </div>
                        </div>
                        <div class="col-lg-9 text-right">
                            <div class="rs-menu-area">
                                <div class="main-menu">
                                    <div class="mobile-menu">
                                        <a class="rs-menu-toggle">
                                            <i class="fa fa-bars"></i>
                                        </a>
                                    </div>
                                    <nav class="rs-menu pr-65">
                                        <ul class="nav-menu">


                                            <li class="menu-item-has-children no-plus">
                                                <a href="#" class="">HiCoder</a>
                                                <ul class="sub-menu">
                                                   
                                                   <li class="">
                                                        <a href="/about">About</a>

                                                    </li>
                                                   <li class="">
                                                        <a href="/contact">Contact</a>

                                                    </li>
                                                   <li class="">
                                                        <a href="https://blog.hicoder.in" target="_blank">Blog</a>

                                                    </li>
                                                    
                                                    
                                                </ul>
                                            </li>

                                            <li class="menu-item-has-children">
                                                <a href="#">Course</a>
                                                <ul class="sub-menu">
                                                    <li><a href="/syllabus">What you learn?</a></li>
                                                    <li><a href="/how-to-apply">How to apply?</a></li>
                                                    <li><a href="/course-fee">Fee Structure</a></li>
                                                    <li><a href="/apply">Apply</a></li>
                                                    <!-- <li><a href="/faq">FAQ</a></li> -->
                                                    
                                                    

                                                </ul>
                                            </li>

                                            <!-- <li class="menu-item-has-children">
                                                <a href="#">Stories</a>
                                                <ul class="sub-menu">
                                                    <li><a href="/industry">Industry</a></li>
                                                    <li><a href="/success-stories">Success Stories</a></li>
                                                    
                                                </ul>
                                            </li> -->


                                            <!-- <li class="menu-item-has-children">
                                                <a href="#">Projects</a>
                                                <ul class="sub-menu">
                                                    <li><a href="shop.html">Phase 1</a></li>
                                                    <li><a href="shop.html">Phase </a></li>
                                                    <li><a href="shop.html">Shop</a></li>

                                                    <li class="last-item"><a href="account.html">My Account</a></li>
                                                </ul>
                                            </li> -->
                                            <li class="menu-item-has-children">
                                                <a href="#">Hire</a>
                                                <ul class="sub-menu">
                                                    <li><a href="/hire">Hire</a></li>
                                                    <!-- <li><a href="/projects">Student Projects</a></li> -->
                                                    <!-- <li><a href="/partners">Partner & Associates</a></li> -->
                                                </ul>
                                            </li>

                                        </ul> <!-- //.nav-menu -->
                                    </nav>
                                </div> <!-- //.main-menu -->
                                <div class="expand-btn-inner">
                                    <ul>
                                        <li  style="background-color:#1C3988; padding: 5px 0; ">
                                            <a class="hidden-xs rs-search text-white px-4" href="/apply">
                                                APPLY NOW
                                            </a>
                                        </li>
                                        <!-- <li class="search-parent">
                                            <a class="hidden-xs rs-search" data-target=".search-modal" data-toggle="modal" href="#">
                                                <i class="flaticon-search"></i>
                                            </a>
                                        </li> -->
                                        <li>
                                            <a id="nav-expander" class="humburger nav-expander" href="#">
                                                <span class="dot1"></span>
                                                <span class="dot2"></span>
                                                <span class="dot3"></span>
                                                <span class="dot4"></span>
                                                <span class="dot5"></span>
                                                <span class="dot6"></span>
                                                <span class="dot7"></span>
                                                <span class="dot8"></span>
                                                <span class="dot9"></span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Menu End -->

            <!-- Canvas Menu start -->
            <nav class="right_menu_togle hidden-md">
                <div class="close-btn">
                    <span id="nav-close" class="humburger">
                        <span class="dot1"></span>
                        <span class="dot2"></span>
                        <span class="dot3"></span>
                        <span class="dot4"></span>
                        <span class="dot5"></span>
                        <span class="dot6"></span>
                        <span class="dot7"></span>
                        <span class="dot8"></span>
                        <span class="dot9"></span>
                    </span>
                </div>
                <div class="canvas-logo">
                    <a href="index.html"><img id="logo" src="assets/images/logo.png" alt="logo"></a>
                </div>
                <div class="offcanvas-text">
                    <p>HiCoder enables students in being capable to develop production grade application by availing full stack development, Soft skills, Analytics and project management skills to get a core software job in the Industry.</p>
                </div>
                <div class="canvas-contact">
                    <ul class="contact">
                        <li><i class="flaticon-location"></i>264/L3, Kavuri Hills Phase 2, HiTech City, Madhapur, Telangana, India, PIN: 500033</li>
                        <li><i class="flaticon-call"></i><a href="tel:+919206980980">(+91) 9206 980 980</a></li>
                        <li><i class="flaticon-email"></i><a href="/cdn-cgi/l/email-protection#6203060f0b11110b0d0c220a0b010d0607104c0b0c"><span class="__cf_email__" data-cfemail="dabbbeb7b3a9a9b3b5b49ab2b3b9b5bebfa8f4b3b4">[email&#160;protected]</span></a></li>
                        <li><i class="flaticon-clock"></i>10:00AM - 06:00PM</li>

                    </ul>
                    <ul class="social">
                        <li><a  href="https://facebook.com/hicoderofficial" target="_blank"><i class="fa fa-facebook"></i></a></li>
                        <li><a  href="https://twitter.com/hicoderofficial" target="_blank"><i class="fa fa-twitter"></i></a></li>
                        <li><a  href="https://instagram.com/hicoderofficial" target="_blank"><i class="fa fa-instagram"></i></a></li>
                        <li><a  href="https://linkedin.com/company/hicoder" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                    </ul>
                </div>
            </nav>
            <!-- Canvas Menu end -->
        </header>
        <!--Header End-->
    </div>
    <!--Full width header End-->




<div class="" style="margin:200px 0px;">
<div class="container my-5"></div>
<h1 class="text-center">Page Not Found</h1>
<p class="text-center" style="font-size: 25px; color: #1C3988;">
    <a href="/"> Home</a> | 
    <a href="/about"> About</a> | 
    <a href="/contact"> Contact</a>

</p>

</div>





    <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script></body>

<!-- Footer Start -->
<footer id="rs-footer" class="rs-footer">
    <div class="container">
        <div class="footer-content pt-80 pb-79 md-pb-64">
            <div class="row">
                <div class="col-lg-4 col-md-12 col-sm-12 footer-widget md-mb-39">
                    <div class="about-widget pr-15">
                        <div class="logo-part">
                            <a href="/"><img src="assets/images/logo.png" alt="Footer Logo"></a>
                        </div>

                        <p class="desc" style="text-align: justify;">HiCoder enables students in being capable to
                            develop production grade application by availing full stack development, Soft skills,
                            Analytics and project management skills to get a core software job in the Industry. </p>

                        <div class="btn-part">
                            <a class="readon" href="/apply">Apply Now</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-12 col-sm-12 md-mb-32 footer-widget  "></div>

                <div class="col-lg-2 col-md-12 col-sm-12 md-mb-32 footer-widget  ">
                    <h4 class="widget-title">Info</h4>
                    <ul class=" pr-40 hc-footer-link ">
                        <li>
                            <p style="margin: 0;padding: 0;"><a href="/">Home</a></p>
                        </li>
                        <li>
                            <p style="margin: 0;padding: 0;"><a href="/about">About</a></p>
                        </li>
                        <li>
                            <p style="margin: 0;padding: 0;"><a href="https://blog.hicoder.in">Blog</a></p>
                        </li>
                        <li>
                            <p style="margin: 0;padding: 0;"><a href="/faq">FAQ</a></p>
                        </li>
                        <li>
                            <p style="margin: 0;padding: 0;"><a href="/contact">Contact</a></p>
                        </li>
                    </ul>
                </div>
                <div class="col-lg-4 col-md-12 col-sm-12 md-mb-32 footer-widget">
                    <h4 class="widget-title">Contact </h4>
                    <ul class="address-widget pr-40">
                        <li>
                            <i class="flaticon-location"></i>
                            <div class="desc"><small> 264/L3, Kavuri Hills Phase 2, HiTech City, Madhapur, Telangana,
                                    India, PIN: 500033</small></div>
                        </li>
                        <li>
                            <i class="flaticon-call"></i>
                            <div class="desc">
                                <a href="tel:+919206980980">(+91) 9206 980 980</a>
                            </div>
                        </li>
                        <li>
                            <i class="flaticon-email"></i>
                            <div class="desc">
                                <a href="/cdn-cgi/l/email-protection#6f0e0b02061c1c0600012f07060c000b0a1d410601"><span class="__cf_email__" data-cfemail="751411181c06061c1a1b351d1c161a1110075b1c1b">[email&#160;protected]</span></a>
                            </div>
                        </li>
                        <li>
                            <i class="flaticon-clock"></i>
                            <div class="desc">
                                10:00AM - 06:00PM
                            </div>
                        </li>
                    </ul>
                </div>

            </div>
        </div>
        <div class="footer-bottom">
            <div class="row y-middle">
                <div class="col-lg-6 col-md-8 sm-mb-21">
                    <div class="copyright">
                        <p>© Copyright | 2020 HiCoder Pvt. Ltd. | All Rights Reserved.</p>
                        <a href="/privacy-policy">Privacy Policy </a> |
                        <a href="/terms-of-service">Terms of Service </a> | * Registration Charges Applied
                    </div>
                </div>
                <div class="col-lg-6 col-md-4 text-right sm-text-center">
                    <ul class="footer-social">
                        <li><a target="_blank" href="https://www.facebook.com/hicoderofficial"><i
                                    class="fa fa-facebook"></i></a></li>
                        <li><a target="_blank" href="https://www.instagram.com/hicoderofficial/"><i
                                    class="fa fa-instagram"></i></a></li>
                        <li><a target="_blank" href="https://twitter.com/hicoderofficial"><i
                                    class="fa fa-twitter"></i></a></li>
                        <li><a target="_blank" href="https://www.linkedin.com/company/69513594/"><i
                                    class="fa fa-linkedin"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer End -->

<!-- start scrollUp  -->
<div id="scrollUp">
    <i class="fa fa-angle-up"></i>
</div>
<!-- End scrollUp  -->

<!-- Search Modal Start -->
<div aria-hidden="true" class="modal fade search-modal" role="dialog" tabindex="-1">
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span class="flaticon-cross"></span>
    </button>
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="search-block clearfix">
                <form>
                    <div class="form-group">
                        <input class="form-control" placeholder="Search Here..." type="text" required="">
                        <button type="submit"><i class="fa fa-search"></i></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Search Modal End -->

<!-- modernizr js -->
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/modernizr-2.8.3.min.js"></script>
<!-- jquery latest version -->
<script src="assets/js/jquery.min.js"></script>
<!-- Bootstrap v4.4.1 js -->
<script src="assets/js/bootstrap.min.js"></script>
<!-- Menu js -->
<script src="assets/js/rsmenu-main.js"></script>
<!-- op nav js -->
<script src="assets/js/jquery.nav.js"></script>
<!-- owl.carousel js -->
<script src="assets/js/owl.carousel.min.js"></script>
<!-- Slick js -->
<script src="assets/js/slick.min.js"></script>
<!-- isotope.pkgd.min js -->
<script src="assets/js/isotope.pkgd.min.js"></script>
<!-- imagesloaded.pkgd.min js -->
<script src="assets/js/imagesloaded.pkgd.min.js"></script>
<!-- wow js -->
<script src="assets/js/wow.min.js"></script>
<!-- Skill bar js -->
<script src="assets/js/skill.bars.jquery.js"></script>
<script src="assets/js/jquery.counterup.min.js"></script>
<!-- counter top js -->
<script src="assets/js/waypoints.min.js"></script>
<!-- video js -->
<script src="assets/js/jquery.mb.YTPlayer.min.js"></script>
<!-- magnific popup js -->
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<!-- Nivo slider js -->
<script src="assets/inc/custom-slider/js/jquery.nivo.slider.js"></script>
<!-- plugins js -->
<script src="assets/js/plugins.js"></script>
<!-- contact form js -->
<script src="assets/js/contact.form.js"></script>
<!-- main js -->
<script src="assets/js/main.js"></script>

<script src="../../public/assets/js/custom.js"></script>


<!-- Global site tag (gtag.js) - Google Analytics Starts -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-Z524KV8ZB7"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag() { dataLayer.push(arguments); }
    gtag('js', new Date());

    gtag('config', 'G-Z524KV8ZB7');
</script>
<!-- Global site tag (gtag.js) - Google Analytics Ends -->


<!-- Start of HubSpot Embed Code -->
<!-- <script type="text/javascript" id="hs-script-loader" async defer src="//js.hs-scripts.com/9042712.js"></script> -->
<!-- End of HubSpot Embed Code -->


<!-- Hotjar Tracking Code for https://hicoder.in -->
<script>
    (function (h, o, t, j, a, r) {
        h.hj = h.hj || function () { (h.hj.q = h.hj.q || []).push(arguments) };
        h._hjSettings = { hjid: 2178412, hjsv: 6 };
        a = o.getElementsByTagName('head')[0];
        r = o.createElement('script'); r.async = 1;
        r.src = t + h._hjSettings.hjid + j + h._hjSettings.hjsv;
        a.appendChild(r);
    })(window, document, 'https://static.hotjar.com/c/hotjar-', '.js?sv=');
</script>

<!-- DO NOT MODIFY -->
<!-- Quora Pixel Code (JS Helper) -->
<script>
    !function (q, e, v, n, t, s) { if (q.qp) return; n = q.qp = function () { n.qp ? n.qp.apply(n, arguments) : n.queue.push(arguments); }; n.queue = []; t = document.createElement(e); t.async = !0; t.src = v; s = document.getElementsByTagName(e)[0]; s.parentNode.insertBefore(t, s); }(window, 'script', 'https://a.quora.com/qevents.js');
    qp('init', '862f55e0ff164b17878e73b2d1b78711');
    qp('track', 'ViewContent');
</script>
<noscript><img height="1" width="1" style="display:none"
        src="https://q.quora.com/_/ad/862f55e0ff164b17878e73b2d1b78711/pixel?tag=ViewContent&noscript=1" /></noscript>
<!-- End of Quora Pixel Code -->

<script>qp('track', 'GenerateLead');</script>




<script>
        //$("submit").on(click, qp('track', 'GenerateLead'))
</script>









</html>
